import cv2 as cv 
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

#Lectura por histograma y ecoalizacion -------------------------------------------------------------------

img = cv.imread("imgs\\Pom.jpg",0)
assert img is not None, "File could not be read"
img_eq = cv.equalizeHist(img)


plt.subplot(2,2,1)
plt.imshow(img,cmap='gray')

plt.subplot(2,2,2)
plt.hist(img.ravel(),256,[0,256])

plt.subplot(2,2,3)
plt.imshow(img_eq,cmap='gray')

plt.subplot(2,2,4)
plt.hist(img_eq.ravel(),256,[0,256])

plt.show()