import cv2 as cv 
import numpy as np
import matplotlib as mp

img1 = cv.imread("imgs\\optimus.png",0)
cv.imshow("Checkboard image", img1)
cv.waitKey(0)
cv.imwrite("imgs\\img2.jpg", img1)