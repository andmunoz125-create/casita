import cv2 as cv 
import numpy as np
import matplotlib
import matplotlib.pyplot as plt


#Transformaciones por partes -------------------------------------------------------------------

img1 = cv.imread("imgs\\optimus.png",0)
print(img1.shape)
height, width = img1.shape

masc = img1<127
img_new = np.zeros(img1.shape)
img_new[masc]= img1[masc]
plt.imshow(img_new, cmap='gray')
plt.show()
print(masc)
exit()

# En taller hay que trabajar (Estiramiento de contraste continuo) () --------------------------

# Corte de nivel de intensidad

