import cv2 as cv 
import numpy as np
import matplotlib
import matplotlib.pyplot as plt

#Lectura por histograma -------------------------------------------------------------------

img = cv.imread("imgs\\Pom.jpg",0)
assert img is not None, "File could not be read"


plt.subplot(1,2,1)

plt.imshow(img,cmap='gray')

plt.subplot(1,2,2)

plt.hist(img.ravel(),256,[0,256])

plt.show()