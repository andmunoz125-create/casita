import cv2 as cv 
import numpy as np
import matplotlib
import matplotlib.pyplot as plt


#Transformaciones de intensidad -------------------------------------------------------------------

img1 = cv.imread("pelicanos\\pelicano2.jpg",0)
print(img1.shape)
height, width = img1.shape

#Imagen a negativa
img_neg = 255 - img1 

plt.subplot(1, 2, 1)
plt.imshow(img1, cmap='gray')
plt.title(f"Original")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(img_neg, cmap='gray')
plt.title("Invertida")
plt.axis("off")
plt.show()

#Transformacion logaritmica (requiere convertir imagen a flotante) -------------------------------
imgf = np.float32(img1.copy())
img_log = np.log(1+imgf)
print(np.max(img_log)) 

#El rango no es el mismo de 0 a 255, para regresarlo hagoe l siguiente proceso
img_log = np.uint8(255*img_log/np.max(img_log))
print(np.max(img_log)) 

plt.subplot(1, 2, 1)
plt.imshow(img1, cmap='gray')
plt.title(f"Original")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(img_log, cmap='gray')
plt.title("Logaritmica")
plt.axis("off")
plt.show()

#Transformacion de potencia o gamma, si es menor a 1 aclara las imagenes ocurre lo contrario si es mayor a 1 --------------------
#Deben evitarse multiplicaciones matriciales y al otmarse una imagen logaritmica debe transformarse
img_g1 = np.pow(imgf, 2)
c = 255/np.max(img_g1)
img_g1 = np.uint8(c*img_g1)

plt.subplot(1, 2, 1)
plt.imshow(img1, cmap='gray')
plt.title(f"Original")
plt.axis("off")

plt.subplot(1, 2, 2)
plt.imshow(img_g1, cmap='gray')
plt.title("Gamma")
plt.axis("off")
plt.show()


