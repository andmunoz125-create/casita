import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt

# David Noguera, Samuel Bolaños, Alejandro Portilla y David Eraso Oñate

# Lista de imágenes 
imagenes = [
    "pelicanos/pelicano1.jpg", 
    "pelicanos/pelicano2.jpg", 
    "pelicanos/pelicano3.jpg", 
    "pelicanos/pelicano4.jpg"
]

# (PRIMERO) Cargar la imagen en escala de grises usando OpenCV para todas las imágenes
for path in imagenes:
    nombre = path.split("/")[-1]  # Extraer el nombre del archivo
    
    print(f"\nProcesando: {nombre}")
    
    # Cargar la imagen en escala de grises (0 indica que la imagen será en gris)
    img = cv.imread(path, 0)  
    if img is None:
        print(f"Error al cargar la imagen {nombre}")
        continue
    
    # Mostrar la imagen en escala de grises
    plt.imshow(img, cmap='gray')
    plt.title(f"Escala de grises - {nombre}")
    plt.show()

    # Determinar ancho y alto de la imagen
    height, width = img.shape
    print("La altura de la imagen es", height)
    print("El ancho de la imagen es", width)

    # Determinar el valor de intensidad máximo y mínimo
    intensidad_max = np.max(img)
    intensidad_min = np.min(img)
    print("Valor de intensidad máximo:", intensidad_max)
    print("Valor de intensidad mínimo:", intensidad_min)

    # Coordenadas del píxel central
    alto = height // 2
    ancho = width // 2
    pixel_central = (alto, ancho)
    print("Coordenadas del píxel central:", pixel_central)

    # (SEGUNDO) Definir los ROI para cada imagen (y1, y2, x1, x2)
    rois = {
        "pelicano1.jpg": (200, 3418, 800, 3700),
        "pelicano2.jpg": (1200, 4800, 400, 3300),
        "pelicano3.jpg": (500, 2300, 550, 3650),
        "pelicano4.jpg": (800, 3400, 1400, 3800),
    }
    
    # Obtener ROI para esta imagen
    y1, y2, x1, x2 = rois[nombre]
    roi = img[y1:y2, x1:x2].copy()

    # Mostrar imagen original y ROI en escala de grises
    plt.subplot(1, 2, 1)
    plt.imshow(img, cmap='gray')
    plt.title(f"Original - {nombre}")
    plt.axis("off")
    
    plt.subplot(1, 2, 2)
    plt.imshow(roi, cmap='gray')
    plt.title("Recorte (ROI)")
    plt.axis("off")
    
    plt.show()

    # (TERCERO) Redimensionar la imagen recortada utilizando diferentes interpolaciones
    tamano_nuevo = (2000, 1500)

    # Vecino más cercano
    img_nearest = cv.resize(roi, tamano_nuevo, interpolation=cv.INTER_NEAREST)

    # Interpolación bilineal
    img_bilinear = cv.resize(roi, tamano_nuevo, interpolation=cv.INTER_LINEAR)

    # Interpolación bicúbica
    img_bicubic = cv.resize(roi, tamano_nuevo, interpolation=cv.INTER_CUBIC)

    # Mostrar las imágenes
    plt.figure(figsize=(15, 7))

    # Imagen original
    plt.subplot(1, 4, 1)
    plt.imshow(roi, cmap='gray')
    plt.title("Imagen Original")
    plt.axis("off")

    # Vecino más cercano
    plt.subplot(1, 4, 2)
    plt.imshow(img_nearest, cmap='gray')
    plt.title("Vecino más Cercano")
    plt.axis("off")

    # Interpolación bilineal
    plt.subplot(1, 4, 3)
    plt.imshow(img_bilinear, cmap='gray')
    plt.title("Bilineal")
    plt.axis("off")

    # Interpolación bicúbica
    plt.subplot(1, 4, 4)
    plt.imshow(img_bicubic, cmap='gray')
    plt.title("Bicúbica")
    plt.axis("off")

    plt.show()

    # (CUARTO) Guardar las imágenes como PNG en la carpeta 'edits'
    cv.imwrite(f"edits/{nombre.split('.')[0]}_nearest.png", img_nearest)
    cv.imwrite(f"edits/{nombre.split('.')[0]}_bilinear.png", img_bilinear)
    cv.imwrite(f"edits/{nombre.split('.')[0]}_bicubic.png", img_bicubic)

    print(f"Las imágenes de {nombre} se han guardado en la carpeta 'edits'.")
