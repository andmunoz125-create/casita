#David Noguera, Samuel Bolaños, Alejandro Portilla, David Eraso
import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt

# ---------------- Funciones auxiliares ----------------

def clasificar_imagen(img):
    """Clasifica la imagen como oscura, clara o normal y
       con bajo o alto contraste a partir de su histograma."""
    hist = cv.calcHist([img], [0], None, [256], [0,256])
    hist_norm = hist / hist.sum()

    # Brillo promedio
    mean_val = np.mean(img)

    if mean_val < 85:
        brillo = "Oscura"
    elif mean_val > 170:
        brillo = "Clara"
    else:
        brillo = "Normal"

    # Contraste
    spread = np.count_nonzero(hist_norm > 0.001)
    if spread < 100:
        contraste = "Bajo contraste"
    else:
        contraste = "Alto contraste"

    return brillo, contraste


def mostrar_histograma(img, titulo="Histograma"):
    plt.hist(img.ravel(), 256, [0,256])
    plt.title(titulo)
    plt.xlabel("Intensidad")
    plt.ylabel("Frecuencia")

# ---------------- Programa principal ----------------

# Lista de imágenes en la carpeta "pelicanos"
imagenes = [f"pelicanos/pelicano{i}.jpg" for i in range(1, 5)]

# ---- (1) Mostrar los 4 pelícanos en escala de grises en una sola ventana ----
plt.figure(figsize=(12,4))
for i, ruta in enumerate(imagenes, 1):
    img = cv.imread(ruta, 0)
    assert img is not None, f"No se pudo leer la imagen {ruta}"
    
    plt.subplot(1, 4, i)
    plt.imshow(img, cmap='gray')
    plt.title(f"Pelicano {i}")
    plt.axis("off")

plt.suptitle("Pelícanos en escala de grises", fontsize=14)
plt.tight_layout()
plt.show()


# ---- (2) Para cada imagen: original + histograma + ecualizada + histograma ----
for i, ruta in enumerate(imagenes, 1):
    img = cv.imread(ruta, 0)
    assert img is not None, f"No se pudo leer la imagen {ruta}"

    # Clasificación
    brillo, contraste = clasificar_imagen(img)
    clasificacion = f"{brillo}, {contraste}"

    # Ecualización
    img_eq = cv.equalizeHist(img)

    # Mostrar resultados
    plt.figure(figsize=(10,6))

    # Imagen original
    plt.subplot(2,2,1)
    plt.imshow(img, cmap='gray')
    plt.title(f"Original ({clasificacion})")
    plt.axis("off")

    # Histograma original
    plt.subplot(2,2,2)
    mostrar_histograma(img, "Histograma original")

    # Imagen ecualizada
    plt.subplot(2,2,3)
    plt.imshow(img_eq, cmap='gray')
    plt.title("Imagen ecualizada")
    plt.axis("off")

    # Histograma ecualizado
    plt.subplot(2,2,4)
    mostrar_histograma(img_eq, "Histograma ecualizado")

    plt.suptitle(f"Resultados Pelicano {i}", fontsize=14)
    plt.tight_layout()
    plt.show()
